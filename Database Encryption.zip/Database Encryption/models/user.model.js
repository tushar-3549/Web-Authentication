const mongoose = require("mongoose");
const encrypt = require("mongoose-encryption");

const userSchema =new mongoose.Schema({
    username: {
        type: String,
        require: true
    },
    password: {
        type: String,
        require: true
    },
    /* phone: {
        type: Number,
        require: false
    }, */
    createdOn: {
        type: Date,
        default: Date.now
    },
});
const encKey = process.env.ENC_KEY;
userSchema.plugin(encrypt, {
  secret: encKey,
  encryptedFields: ["password"],
});

module.exports = mongoose.model("user", userSchema);